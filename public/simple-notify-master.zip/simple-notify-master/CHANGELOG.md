# simple-notify Changelog

## 0.5.0

- [Feature] Added raw html support for `text` parameter https://github.com/dgknca/simple-notify/pull/5

## 0.4.0

- Added 3 new positions `'(top/bottom) x-center'`, `'(left/right) y-center'` and `'center'`
- Slide effect has been combined with fade

## 0.3.1

- Added custom typescript types

## 0.3.0

- `isIcon` replaced with `showIcon`
- `isCloseButton` replaced with `showCloseButton`

## 0.2.0

### Added

- Added `distance` and `position` parameters.
